module.exports = {
  plugins: [
    require('autoprefixer'),
    require('cssnano'),
    require('postcss-nested'),
    require('postcss-nesting')
  ]
};